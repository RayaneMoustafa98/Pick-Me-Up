<?php
	include ("connections.php");

	$data_from_ionic = json_decode(file_get_contents("php://input"));

	$username = $data_from_ionic->username;
	$email = $data_from_ionic->email;
    $phonenb = $data_from_ionic->phonenb;
	$password = $data_from_ionic->password;


	
	if(isset($username) && !empty($username) && isset($email) && !empty($email)&& isset($phonenb) && !empty($phonenb) && isset($password) && !empty($password)) {
		$hash = hash("sha256", $password);
		$role = 1;
		$query = "INSERT INTO newUsers(username, email,phonenb, password, role) VALUES (?, ?, ?, ?, ?, ?)";
		$stmt = $connect->prepare($query);

		$stmt->bind_param("sssi", $full_name, $email, $phonenb, $hash, $role);

		$result = $stmt->execute();

		$res = "";
		if($result) 
		{
			$res = "New User registered successfully";
			$json = json_encode($res);
			print($json);

		} else 
		{
			$res = "Failed to register new user";
			$json = json_encode($res);
			print($json);
		}

	} else {
		$r = "User input is incomplete";
		$json = json_encode($r);
		print($json);
	}

?>
