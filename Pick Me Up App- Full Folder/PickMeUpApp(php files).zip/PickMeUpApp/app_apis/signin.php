<?php
	include ("connections.php");
	session_start();
	$data_from_ionic = json_decode(file_get_contents("php://input"));

	$user_email = $data_from_ionic->user_email;
	$password = $data_from_ionic->password;
	$hash = hash("sha256", $password);

	if(isset($user_email) && !empty($user_email) && isset($password) && !empty($password)) {
		$query = "SELECT user_email, password FROM users WHERE user_email=? AND password=?";

		
		$stmt = $connect->prepare($query);
		$stmt->bind_param("ss", $user_email, $hash);
		$stmt->execute();
		$results = $stmt->get_result();
		$user = $results->fetch_assoc();

		$json0 = json_encode($user);
		// print $json0;
		
		$res = "";
		// print($json0 != null);
		
		if($json0 != null) {
			$res = "User Found";
			$json = json_encode($res);
			print($json);
		} else {
			$res = "User not found";
			$json = json_encode($res);
			print($json);
		}

	} else {
		$res = "Username or password is empty.";
		$json = json_encode($res);
		print($json);
	}

?>