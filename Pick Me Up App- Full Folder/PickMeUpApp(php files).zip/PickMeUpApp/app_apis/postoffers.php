<?php

include ("connections.php");
header('Access-Control-Allow-Headers: Content-Type');

$data_from_ionic = json_decode(file_get_contents("php://input"));

$fullName = $data_from_ionic->fullName;
$location = $data_from_ionic->location;
$destination = $data_from_ionic->destination;
$time = $data_from_ionic ->time;
$seatsAvailable = $data_from_ionic-> seats_available;
$hasLicense = $data_from_ionic->hasLicense;

$query = "INSERT INTO postOffers(fullName, location, destination, time, seats_available, hasLicense) VALUES (?, ?, ?,?,?)";
$stmt = $connect->prepare($query);

$stmt->bind_param('sis', $fullName, $location, $destination,$time , $seatsAvailable, $hasLicense );
$stmt->execute();

echo $fullName;
echo $location;
echo $destination;
echo $time;
echo $seatsAvailable;
echo $hasLicense;



?>