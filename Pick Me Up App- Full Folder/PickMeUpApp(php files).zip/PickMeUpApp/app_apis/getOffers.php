<?php

include "connections.php";

$query = "SELECT * FROM postoffer";

$stmt = $cnnx->prepare($query);
$stmt->execute();

$results = $stmt->get_result();

$response = [];
while($offer = $results->fetch_assoc())
{
    $response[] = $offer;
    
}

$offers_json = json_encode($response);
echo $offers_json;
?>